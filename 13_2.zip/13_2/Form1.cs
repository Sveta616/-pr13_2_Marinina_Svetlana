﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static _13_2.Student;


namespace _13_2
{
    public partial class Form1 : Form
    {

        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
         private IList<Student> studentList = new List<Student>();
        private DataGridViewColumn GetDataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Имя";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn GetDataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name= "";
                dataGridViewColumn2.HeaderText = "Фамилия";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn GetDataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "Номер зачётки";
                dataGridViewColumn3.ValueType = typeof(int);
                dataGridViewColumn3.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn3;
        }


           private void InitDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(GetDataGridViewColumn1());
            dataGridView1.Columns.Add(GetDataGridViewColumn2());
            dataGridView1.Columns.Add(GetDataGridViewColumn3());
            dataGridView1.AutoResizeColumns();
        }
        private void ShowListInGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (Student s in studentList)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell1.Value = s.GetName();
                cell2.ValueType = typeof(string);
                cell2.Value = s.GetSurname();
                cell3.ValueType = typeof(int);
                cell3.Value = s.GetBookName();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                dataGridView1.Rows.Add(row);
            }
        }
        private void deleteStudent(int elementIndex)
        {
            studentList.RemoveAt(elementIndex);
            ShowListInGrid();
        } 
        public Form1()
        {
            InitializeComponent();
            InitDataGridView();
        }
        private void addStudent(string name, string surname, int bookname)
        {
            Student student = new Student(name, surname, bookname);
            studentList.Add(student);
            ShowListInGrid();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                addStudent(textBox1.Text, textBox2.Text, (int)numericUpDown1.Value);
                textBox1.Text = "";
                textBox2.Text = "";
                
            }
            catch
            {
                MessageBox.Show("Заполните поле");
            }
        }
        

    


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
               
            
        }


        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            DialogResult r = MessageBox.Show("Удалить студента?", "Удаление", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
            {
                deleteStudent(a);
            }
        }

        private void сортироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
        }

        private void редактироватьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int b = dataGridView1.CurrentRow.Index;
            dataGridView1.Rows[b].Cells[0].Value = textBox1.Text;
            dataGridView1.Rows[b].Cells[1].Value = textBox2.Text;
        }

    }
    }

